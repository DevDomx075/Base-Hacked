module.exports = {
    nomeBot: 'ˢʸˢᵗᵉᵐHACKΞD',
    prefixo: '!',

    donos: [
        '163849445625894',
        '850714233'
    ],

    emoji: '💀'
}
