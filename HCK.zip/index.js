const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion
} = require('@whiskeysockets/baileys')

const pino = require('pino')
const qrcode = require('qrcode-terminal')

// handler
const handler = require('./src/handler')

// 🚀 iniciar bot
async function startHCK() {
    const { state, saveCreds } = await useMultiFileAuthState('./auth')
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        auth: state,
        browser: ['ˢʸˢᵗᵉᵐHACKΞD', 'Chrome', '1.0']
    })

    // ==============================
    // 🔐 SALVAR SESSÃO
    // ==============================
    sock.ev.on('creds.update', saveCreds)

    // ==============================
    // 📲 CONEXÃO + QR
    // ==============================
    sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {

        // 🔳 MOSTRAR QR
        if (qr) {
            console.log('\n📲 Escaneia o QR abaixo:\n')
            qrcode.generate(qr, { small: true })
        }

        if (connection === 'close') {
            const reason = lastDisconnect?.error?.output?.statusCode

            if (reason === DisconnectReason.loggedOut) {
                console.log('❌ Sessão encerrada. Apague a pasta /auth.')
            } else {
                console.log('🔄 Reconectando...')
                startHCK()
            }

        } else if (connection === 'open') {
            console.log('ˢʸˢᵗᵉᵐHACKΞD | Conectado! 🔥')
        }
    })

    // ==============================
    // 📩 MENSAGENS
    // ==============================
    sock.ev.on('messages.upsert', async ({ messages }) => {
        try {
            const msg = messages[0]
            if (!msg) return

            // ignorar status
            if (msg.key?.remoteJid === 'status@broadcast') return

            await handler(sock, msg)

        } catch (err) {
            console.log('Erro mensagem:', err)
        }
    })

    // ==============================
    // 👥 EVENTOS DE GRUPO
    // ==============================
    sock.ev.on('group-participants.update', async (update) => {
        try {
            await handler(sock, {
                type: 'group-update',
                data: update
            })
        } catch (err) {
            console.log('Erro grupo:', err)
        }
    })
}

// 🚀 start
startHCK()
