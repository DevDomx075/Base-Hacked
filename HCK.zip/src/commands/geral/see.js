const { execSync } = require('child_process')
const fs = require('fs')
const path = require('path')
const responder = require('../../utils/responder')

// delay
const delay = ms => new Promise(res => setTimeout(res, ms))

async function digitando(sock, from, tempo = 500) {
    try {
        await sock.sendPresenceUpdate('composing', from)
        await delay(tempo)
        await sock.sendPresenceUpdate('paused', from)
    } catch {}
}

// pegar texto
function getText(msg) {
    return (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        ''
    ).trim()
}

// 🔥 USANDO PYTHON (resolve erro do yt-dlp quebrado)
const YTDLP = 'python3 -m yt_dlp'

// 🚀 EXECUTOR
function run(cmd) {
    try {
        return execSync(cmd, {
            encoding: 'utf-8',
            shell: '/data/data/com.termux/files/usr/bin/bash'
        })
    } catch (e) {
        console.log('CMD ERROR:', e?.stderr?.toString())
        throw e
    }
}

module.exports = {
    name: 'see',
    aliases: ['playvideo','ver'],

    run: async ({ sock, msg, from }) => {
        try {
            const text = getText(msg)
            if (!text) return

            const args = text.split(' ')
            args.shift()

            if (!args[0]) {
                return responder({
                    sock,
                    from,
                    msg,
                    texto: '❌ Use: !see nome ou link'
                })
            }

            let query = args.join(' ')

            // 🔎 reação
            if (msg.key) {
                await sock.sendMessage(from, {
                    react: { text: '🔎', key: msg.key }
                })
            }

            await digitando(sock, from, 500)

            let videoUrl = query

            // 🔍 buscar se não for link
            if (!query.startsWith('http')) {
                const json = run(`${YTDLP} --dump-json "ytsearch1:${query}"`)

                try {
                    const data = JSON.parse(json)
                    videoUrl = data.webpage_url
                } catch {
                    return responder({
                        sock,
                        from,
                        msg,
                        texto: '❌ Não encontrei.'
                    })
                }
            }

            const dir = '/data/data/com.termux/files/home/HCK/src/tmp'
            if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

            const file = path.join(dir, `video_${Date.now()}.mp4`)

            // ⚡ DOWNLOAD RÁPIDO
            run(`${YTDLP} -f "mp4[height<=720]" --no-playlist -o "${file}" "${videoUrl}"`)

            if (!fs.existsSync(file)) {
                return responder({
                    sock,
                    from,
                    msg,
                    texto: '❌ Falha no download.'
                })
            }

            await responder({
                sock,
                from,
                msg,
                texto: '🎬 Enviando vídeo...'
            })

            await sock.sendMessage(from, {
                video: { url: file },
                mimetype: 'video/mp4',
                caption: '🎬 HD'
            }, { quoted: msg })

            fs.unlinkSync(file)

            // ✅ reação final
            if (msg.key) {
                await sock.sendMessage(from, {
                    react: { text: '⚡', key: msg.key }
                })
            }

        } catch (err) {
            console.log('Erro no see:', err)

            await responder({
                sock,
                from,
                msg,
                texto: '❌ Erro ao baixar vídeo.'
            })
        }
    }
}
