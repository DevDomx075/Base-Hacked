// src/commands/geral/play.js
const { spawn } = require('child_process')
const fs = require('fs')
const path = require('path')
const bordas = require('../../utils/bordas')
const responder = require('../../utils/responder')

//  delay
const delay = ms => new Promise(res => setTimeout(res, ms))

//  simular gravando
async function gravandoAudio(sock, from, tempo = 3500) {
    try {
        await sock.sendPresenceUpdate('recording', from)
        await delay(tempo)
        await sock.sendPresenceUpdate('paused', from)
    } catch {}
}

//tempo
function formatTime(sec) {
    const m = Math.floor(sec / 60)
    const s = sec % 60
    return `${m}:${('0' + s).slice(-2)}`
}

//  barra dinâmica
function gerarBarra(durationSec) {
    const total = 10
    const pos = Math.floor(Math.random() * total)
    let barra = ''
    for (let i = 0; i < total; i++) {
        barra += i === pos ? '❍' : '─'
    }
    return `0:00 ━${barra} ${formatTime(durationSec)}`
}

//  pegar texto
function getText(msg) {
    return (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        msg.message?.imageMessage?.caption ||
        msg.message?.videoMessage?.caption ||
        ''
    ).trim()
}

// usar Python
const PYTHON3 = 'python3'
const YTDLP_ARGS = ['-m', 'yt_dlp']

module.exports = {
    name: 'play',
    aliases: ['musica', 'song'],

    run: async ({ sock, msg, from }) => {
        try {
            const text = getText(msg)
            if (!text) return

            const args = text.split(' ')
            args.shift()
            if (args.length < 1) {
                return await responder({
                    sock,
                    from,
                    msg,
                    texto: '❌ Use: !play nome da música'
                })
            }

            const query = args.join(' ')

            // reação inicial
            if (msg.key) {
                await sock.sendMessage(from, {
                    react: { text: '💆🏿‍♂️', key: msg.key }
                })
            }

//simula gravando enquanto busca
            await gravandoAudio(sock, from, 3000)

            // 🔎 busca info
            const infoProcess = spawn(PYTHON3, [...YTDLP_ARGS, '--no-warnings', '--dump-json', '--flat-playlist', `ytsearch1:${query}`])
            let jsonOutput = ''
            infoProcess.stdout.on('data', d => jsonOutput += d.toString())

            infoProcess.on('close', async () => {
                if (!jsonOutput) {
                    return await responder({
                        sock,
                        from,
                        msg,
                        texto: '❌ Música não encontrada.'
                    })
                }

                let video
                try { video = JSON.parse(jsonOutput) }
                catch {
                    return await responder({
                        sock,
                        from,
                        msg,
                        texto: '❌ Erro ao processar.'
                    })
                }

                const title = video.title || 'Desconhecido'
                const uploader = video.uploader || 'Desconhecido'
                const durationSec = video.duration || 0
                const thumbnail = video.thumbnail || "https://i.imgur.com/uE4sO6N.jpeg"

                const tempDir = '/data/data/com.termux/files/home/HCK/src/tmp'
                if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

                const filePath = path.join(tempDir, `play_${Date.now()}.mp3`)

                // DOWNLOAD ÁUDIO
                const downloadProcess = spawn(PYTHON3, [
                    ...YTDLP_ARGS,
                    '--no-warnings',
                    '--no-playlist',
                    '-f', 'bestaudio',
                    '--extract-audio',
                    '--audio-format', 'mp3',
                    '--audio-quality', '0',
                    '-o', filePath,
                    video.url || video.webpage_url
                ])

                downloadProcess.on('close', async () => {
                  
                    if (!fs.existsSync(filePath)) {
                     // simula gravando enquanto busca
            await gravandoAudio(sock, from, 2000)
                        return await responder({
                            sock,
                            from,
                            msg,
                            texto: '❌ Erro ao baixar áudio.'
                        })
                    }

  // PLAYER VISUAL sem borda extra
const textoFinal = `
  Escuta e baixa mudía com Facilidade!

_Titúlo:_ *${title}*
_*Canal:*_ *${uploader}*
  ️❤️ Curtido
${gerarBarra(durationSec)}
  ↻ ⊲ Ⅱ ⊳ ↺ 

  *VOLUME: ■■■■■□□□ 100%*

_Seu áudio abaixo_...
`


                    // 🖼️ envia card
                    await responder({
                        sock,
                        from,
                        msg,
                        texto: textoFinal,
                        imagem: thumbnail
                    })

                    // 🎤 simula gravando antes de enviar áudio
                    await gravandoAudio(sock, from, 2000)

                    // 🔊 envia áudio
                    await sock.sendMessage(from, {
                        audio: { url: filePath },
                        mimetype: 'audio/mpeg',
                        fileName: `${title}.mp3`
                    }, { quoted: msg })

                    // 🧹 limpar
                    fs.unlinkSync(filePath)

                    // ✅ reação final
                    if (msg.key) {
                        await sock.sendMessage(from, {
                            react: { text: '🎶', key: msg.key }
                        })
                    }
                })
            })

        } catch (err) {
            console.error('Erro no play:', err)
        }
    }
}
