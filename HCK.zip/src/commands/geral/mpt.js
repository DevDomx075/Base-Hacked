const { spawn } = require('child_process')
const fs = require('fs')
const path = require('path')
const responder = require('../../utils/responder')

// delay
const delay = ms => new Promise(res => setTimeout(res, ms))

// 🎤 simular gravando
async function gravando(sock, from, tempo = 2000) {
    try {
        await sock.sendPresenceUpdate('recording', from)
        await delay(tempo)
        await sock.sendPresenceUpdate('paused', from)
    } catch {}
}

// 📌 pegar texto
function getText(msg) {
    return (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        ''
    ).trim()
}

const PYTHON = 'python3'
const YTDLP = ['-m', 'yt_dlp']

module.exports = {
    name: 'mp3',
    aliases: ['toaudio', 'tomp3'],

    run: async ({ sock, msg, from }) => {
        try {
            const text = getText(msg)
            const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage

            const dir = '/data/data/com.termux/files/home/HCK/src/tmp'
            if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

            const raw = path.join(dir, `raw_${Date.now()}.mp4`)
            const mp3 = path.join(dir, `audio_${Date.now()}.mp3`)

            // 🎯 reação
            if (msg.key) {
                await sock.sendMessage(from, {
                    react: { text: '🎧', key: msg.key }
                })
            }

            // 🎬 CASO 1: respondeu vídeo
            if (quoted?.videoMessage) {

                await gravando(sock, from, 2000)
const { downloadContentFromMessage } = require('@whiskeysockets/baileys')

const stream = await downloadContentFromMessage(
    quoted.videoMessage,
    'video'
)

let buffer = Buffer.from([])

for await (const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk])
}

                fs.writeFileSync(raw, buffer)

                await converter()

            } else {

                // 🎬 CASO 2: URL
                if (!text) {
                    return responder({
                        sock,
                        from,
                        msg,
                        texto: '❌ Use: !mp3 link ou responda um vídeo'
                    })
                }

                const args = text.split(' ')
                args.shift()
                const url = args[0]

                await gravando(sock, from, 2000)

                const dl = spawn(PYTHON, [
                    ...YTDLP,
                    '-f', 'bestaudio',
                    '--no-playlist',
                    '-o', raw,
                    url
                ])

                await new Promise(resolve => dl.on('close', resolve))

                if (!fs.existsSync(raw)) {
                    return responder({
                        sock,
                        from,
                        msg,
                        texto: '❌ Erro ao baixar áudio.'
                    })
                }

                await converter()
            }

            // 🔄 converter pra MP3
            async function converter() {

                const ff = spawn('ffmpeg', [
                    '-i', raw,
                    '-vn',
                    '-ar', '44100',
                    '-ac', '2',
                    '-b:a', '192k',
                    mp3
                ])

                ff.on('close', async () => {

                    if (!fs.existsSync(mp3)) {
                        return responder({
                            sock,
                            from,
                            msg,
                            texto: '❌ Erro ao converter áudio.'
                        })
                    }

                    await responder({
                        sock,
                        from,
                        msg,
                        texto: '🎧 Enviando áudio...'
                    })

                    // 🎤 simula gravando antes de enviar
                    await gravando(sock, from, 2000)

                    await sock.sendMessage(from, {
                        audio: { url: mp3 },
                        mimetype: 'audio/mpeg',
                        fileName: 'audio.mp3'
                    }, { quoted: msg })

                    // limpar
                    fs.unlinkSync(raw)
                    fs.unlinkSync(mp3)

                    if (msg.key) {
                        await sock.sendMessage(from, {
                            react: { text: '✅', key: msg.key }
                        })
                    }
                })
            }

        } catch (err) {
            console.log('Erro no mp3:', err)

            await responder({
                sock,
                from,
                msg,
                texto: '❌ Erro ao processar áudio.'
            })
        }
    }
}
