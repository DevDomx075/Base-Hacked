const { execSync } = require('child_process')
const fs = require('fs')
const path = require('path')
const responder = require('../../utils/responder')

const delay = ms => new Promise(res => setTimeout(res, ms))

async function digitando(sock, from, tempo = 2000) {
    try {
        await sock.sendPresenceUpdate('composing', from)
        await delay(tempo)
        await sock.sendPresenceUpdate('paused', from)
    } catch {}
}

async function gravando(sock, from, tempo = 2000) {
    try {
        await sock.sendPresenceUpdate('recording', from)
        await delay(tempo)
        await sock.sendPresenceUpdate('paused', from)
    } catch {}
}

function getText(msg) {
    return (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        ''
    ).trim()
}

// 🚀 EXECUTOR 100% SEGURO
function run(cmd) {
    try {
        return execSync(cmd, { encoding: 'utf-8' })
    } catch (err) {
        console.log('CMD ERRO:', err?.stderr?.toString())
        throw err
    }
}

module.exports = {
    name: 'baixar',
    aliases: ['dl','media'],

    run: async ({ sock, msg, from }) => {
        try {
            const text = getText(msg)
            if (!text) return

            const args = text.split(' ')
            args.shift()

            if (!args[0]) {
                return responder({
                    sock,
                    from,
                    msg,
                    texto: '❌ Use: baixar [mp3/mp4] nome ou link'
                })
            }

            let tipo = 'mp4'

            if (args[0] === 'mp3') {
                tipo = 'mp3'
                args.shift()
            } else if (args[0] === 'mp4') {
                tipo = 'mp4'
                args.shift()
            }

            const query = args.join(' ')

            if (!query) {
                return responder({
                    sock,
                    from,
                    msg,
                    texto: '❌ Coloque nome ou link'
                })
            }

            if (msg.key) {
                await sock.sendMessage(from, {
                    react: { text: '🔎', key: msg.key }
                })
            }

            await digitando(sock, from, 2000)

            let videoUrl = query

            // 🔍 BUSCAR
            if (!query.startsWith('http')) {
                const json = run(`yt-dlp --dump-json "ytsearch1:${query}"`)

                try {
                    const data = JSON.parse(json)
                    videoUrl = data.webpage_url
                } catch {
                    return responder({
                        sock,
                        from,
                        msg,
                        texto: '❌ Não encontrei.'
                    })
                }
            }

            const dir = '/data/data/com.termux/files/home/HCK/src/tmp'
            if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

            const base = path.join(dir, `file_${Date.now()}`)

            if (tipo === 'mp3') {

                const file = base + '.mp3'

                run(`yt-dlp -f bestaudio --extract-audio --audio-format mp3 -o "${file}" "${videoUrl}"`)

                await gravando(sock, from, 2000)

                await sock.sendMessage(from, {
                    audio: { url: file },
                    mimetype: 'audio/mpeg'
                }, { quoted: msg })

                fs.unlinkSync(file)

            } else {

                const raw = base + '_raw.mp4'
                const final = base + '.mp4'

                run(`yt-dlp -f bestvideo+bestaudio --merge-output-format mp4 -o "${raw}" "${videoUrl}"`)

                run(`ffmpeg -i "${raw}" -vf scale=1280:-2 -c:v libx264 -preset fast -crf 28 -c:a aac -b:a 128k -movflags +faststart "${final}"`)

                await responder({
                    sock,
                    from,
                    msg,
                    texto: '🎬 Enviando vídeo...'
                })

                await sock.sendMessage(from, {
                    video: { url: final },
                    mimetype: 'video/mp4'
                }, { quoted: msg })

                fs.unlinkSync(raw)
                fs.unlinkSync(final)
            }

            if (msg.key) {
                await sock.sendMessage(from, {
                    react: { text: '✅', key: msg.key }
                })
            }

        } catch (err) {
            console.log('Erro baixar:', err)

            await responder({
                sock,
                from,
                msg,
                texto: '❌ Erro ao baixar mídia.'
            })
        }
    }
}
