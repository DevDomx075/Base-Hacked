const responder = require('../../utils/responder')

// mesma função que você usa no handler/ping
const delay = ms => new Promise(res => setTimeout(res, ms))

async function digitando(sock, jid, texto = '') {
    try {
        let tempo = texto.length * 25
        tempo += Math.floor(Math.random() * 400)

        if (tempo < 400) tempo = 400
        if (tempo > 4000) tempo = 4000

        await sock.sendPresenceUpdate('composing', jid)
        await delay(tempo)
        await sock.sendPresenceUpdate('paused', jid)
    } catch {}
}

module.exports = {
    name: 'info',
    aliases: ['botinfo'],

    run: async ({ sock, msg, from, sender, config }) => {
        try {
            const senderNumber = sender.split('@')[0]

            const now = new Date()
            const hora = now.toLocaleTimeString()
            const data = now.toLocaleDateString()

            const h = now.getHours()
            let saudacao = '🌙 Boa noite'
            if (h >= 5 && h < 12) saudacao = '🌞 Bom dia'
            else if (h >= 12 && h < 18) saudacao = '🌤️ Boa tarde'

            const prefixo = config.prefixo || '!'
            const nomeBot = config.nomeBot || 'ˢʸˢᵗᵉᵐHACKΞD'
            const dono = config.donos?.[0] || 'Desconhecido'

            let nomeGrupo = 'Chat privado'
            let membros = '-'
            let admins = '-'

            if (from.endsWith('@g.us')) {
                try {
                    const metadata = await sock.groupMetadata(from)
                    nomeGrupo = metadata.subject
                    membros = metadata.participants.length
                    admins = metadata.participants.filter(p => p.admin).length
                } catch {}
            }

            const texto = `
${saudacao}, @${senderNumber}

🤖 Bot: ${nomeBot}
👑 Dono: ${dono}
⌘ Prefixo: ${prefixo}

🕒 Hora: ${hora}
📅 Data: ${data}

👥 Chat: ${nomeGrupo}
👤 Membros: ${membros}
🛡️ Admins: ${admins}
`

            // 🔥 SIMULAÇÃO IGUAL AO PING
            await digitando(sock, from, texto)

            // 🚀 ENVIO
            await responder({
                sock,
                from,
                msg,
                texto,
                titulo: nomeBot,
                subtitulo: 'Informações do sistema ⚡',
                imagem: 'https://i.imgur.com/vdmgNvS.jpeg',
                canalJid: '120363424816359070@newsletter',
                canalNome: '✦ ˢʸˢᵗᵉᵐHACKΞD ✦'
            })

        } catch (err) {
            console.log('Erro no comando info:', err)
        }
    }
}
