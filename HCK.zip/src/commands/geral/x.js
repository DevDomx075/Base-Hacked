const baixarVideo = require('../../utils/baixarVideo')
module.exports = {
    name: 'x',
    aliases: ['twitter','tw'],

    run: async (ctx) => baixarVideo(ctx)
}
