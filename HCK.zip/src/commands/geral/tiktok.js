const baixarVideo = require('../../utils/baixarVideo')
module.exports = {
    name: 'tiktok',
    aliases: ['tk'],

    run: async (ctx) => baixarVideo(ctx)
}
