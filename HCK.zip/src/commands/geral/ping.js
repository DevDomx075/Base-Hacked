// src/commands/geral/ping.js
const responder = require('../../utils/responder')
const os = require('os')

module.exports = {
    name: 'ping',
    aliases: ['p'],

    run: async ({ sock, msg, from, sender, config }) => {
        try {
            const senderNumber = sender.split('@')[0]

            // ⏱️ Ping REAL (medindo resposta do envio)
            const start = Date.now()
            await sock.sendPresenceUpdate('composing', from)
            const latency = Date.now() - start

            // 🕒 Hora atual
            const now = new Date()
            const hora = now.toLocaleTimeString()

            // 🌤️ Saudação
            const h = now.getHours()
            let saudacao = '🌙 Boa noite'
            if (h >= 5 && h < 12) saudacao = '🌞 Bom dia'
            else if (h >= 12 && h < 18) saudacao = '🌤️ Boa tarde'

            // ⚡ Prefixo
            const prefixo = config.prefixo || '!'

            // 🧠 Tempo online
            const uptime = process.uptime()
            const horas = Math.floor(uptime / 3600)
            const minutos = Math.floor((uptime % 3600) / 60)
            const segundos = Math.floor(uptime % 60)

            // 💻 SISTEMA
            const totalMem = os.totalmem() / 1024 / 1024
            const freeMem = os.freemem() / 1024 / 1024
            const usedMem = totalMem - freeMem
            const memPercent = Math.floor((usedMem / totalMem) * 100)


		const cpus = os.cpus()
const cpu = cpus && cpus.length ? cpus[0].model : 'Desconhecido'
            // 📊 Barra de status
            function barra(percent) {
                const total = 10
                const filled = Math.floor((percent / 100) * total)
                const empty = total - filled
                return '█'.repeat(filled) + '░'.repeat(empty)
            }

            // 💬 TEXTO
            const texto = `
${saudacao}, @${senderNumber}

👾 Bot: ${config.nomeBot || 'ˢʸˢᵗᵉᵐHACKΞD'}
⌘ Prefixo: ${prefixo}
🕒 Hora: ${hora}

📡 Ping: ${latency}ms
🧠 Online: ${horas}h ${minutos}m ${segundos}s

💻 Sistema:
RAM: ${memPercent}% [${barra(memPercent)}]
CPU: [${barra(memPercent)}]
`

            // 🚀 Enviar
            await responder({
                sock,
                from,
                msg,
                texto,
                titulo: config.nomeBot || 'ˢʸˢᵗᵉᵐHACKΞD',
                subtitulo: 'Status do sistema ⚡',
                imagem: 'https://i.imgur.com/vdmgNvS.jpeg',
                canalJid: '120363424816359070@newsletter',
                canalNome: '✦ ˢʸˢᵗᵉᵐHACKΞD ✦'
            })

        } catch (err) {
            console.log('Erro no comando ping:', err)
        }
    }
}
