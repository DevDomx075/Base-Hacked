const responder = require('../../utils/responder')
const bordas = require('../../utils/bordas')

module.exports = {
    name: 'abrir',
    aliases: ['open'],

    run: async ({ sock, msg, from, sender }) => {
        try {
            if (!from.endsWith('@g.us')) {
                return responder({
                    sock,
                    from,
                    msg,
                    texto: '❌ Este comando só funciona em grupos.',
                    titulo: 'Sistema de Grupo',
                    subtitulo: 'Erro de contexto ⚡',
                    imagem: 'https://i.imgur.com/vdmgNvS.jpeg'
                })
            }

            // 🔹 Simulação de escrevendo
            await sock.sendPresenceUpdate('composing', from)
            await new Promise(r => setTimeout(r, 1500)) // aguarda 1.5s para parecer humano

            // 🔹 Tenta abrir grupo
            try {
                await sock.groupSettingUpdate(from, 'not_announcement') // abrir grupo
                await responder({
                    sock,
                    from,
                    msg,
                    texto: '🔓 Grupo aberto. Todos podem enviar mensagens.',
                    titulo: 'Sistema de Grupo',
                    subtitulo: 'Modo livre ativado ⚡',
                    imagem: 'https://i.imgur.com/vdmgNvS.jpeg'
                })
            } catch (err) {
                console.log('Erro ao abrir grupo:', err)
                // 🔹 Sistema auxiliar dispara se bot não consegue abrir
                await responder({
                    sock,
                    from,
                    msg,
                    texto: '❌ Não consegui abrir o grupo. Provavelmente não sou ADM neste grupo.',
                    titulo: 'Sistema Auxiliar',
                    subtitulo: 'Permissão insuficiente ⚡',
                    imagem: 'https://i.imgur.com/vdmgNvS.jpeg'
                })
            }

        } catch (err) {
            console.log('Erro no comando abrir:', err)
            await responder({
                sock,
                from,
                msg,
                texto: '⚠️ Ocorreu um erro interno.',
                titulo: 'Sistema Auxiliar',
                subtitulo: 'Erro inesperado',
                imagem: 'https://i.imgur.com/vdmgNvS.jpeg'
            })
        }
    }
}
