const responder = require('../../utils/responder')
const bordas = require('../../utils/bordas')

module.exports = {
    name: 'fechar',
    aliases: ['close'],

    run: async ({ sock, msg, from, sender }) => {
        try {
            if (!from.endsWith('@g.us')) {
                return responder({
                    sock,
                    from,
                    msg,
                    texto: '❌ Este comando só funciona em grupos.',
                    titulo: 'Sistema de Grupo',
                    subtitulo: 'Erro de contexto ⚡',
                    imagem: 'https://i.imgur.com/vdmgNvS.jpeg'
                })
            }

            // 🔹 Simulação de escrevendo
            await sock.sendPresenceUpdate('composing', from)
            await new Promise(r => setTimeout(r, 1500)) // aguarda 1.5s para parecer humano

            // 🔹 Tenta fechar grupo
            try {
                await sock.groupSettingUpdate(from, 'announcement') // fechar grupo
                await responder({
                    sock,
                    from,
                    msg,
                    texto: '🔒 Grupo fechado. Apenas administradores podem enviar mensagens.',
                    titulo: 'Sistema de Grupo',
                    subtitulo: 'Modo restrito ativado ⚡',
                    imagem: 'https://i.imgur.com/vdmgNvS.jpeg'
                })
            } catch (err) {
                console.log('Erro ao fechar grupo:', err)
                // 🔹 Sistema auxiliar dispara se bot não consegue fechar
                await responder({
                    sock,
                    from,
                    msg,
                    texto: '❌ Não consegui fechar o grupo. Provavelmente não sou ADM neste grupo.',
                    titulo: 'Sistema Auxiliar',
                    subtitulo: 'Permissão insuficiente ⚡',
                    imagem: 'https://i.imgur.com/vdmgNvS.jpeg'
                })
            }

        } catch (err) {
            console.log('Erro no comando fechar:', err)
            await responder({
                sock,
                from,
                msg,
                texto: '⚠️ Ocorreu um erro interno.',
                titulo: 'Sistema Auxiliar',
                subtitulo: 'Erro inesperado',
                imagem: 'https://i.imgur.com/vdmgNvS.jpeg'
            })
        }
    }
}
