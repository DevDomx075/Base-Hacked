// src/utils/adminCheck.js
const responder = require('./responder')

/**
 * @param sock - conexão
 * @param from - jid do grupo
 * @param sender - quem executou
 * @param msg - mensagem original
 * @param requireBotAdmin - se o comando exige que o bot seja admin
 * @param requireUserAdmin - se o comando exige que o usuário seja admin
 * @returns {ok: boolean, error: boolean}
 */
module.exports = async ({
    sock,
    from,
    sender,
    msg,
    requireBotAdmin = false,
    requireUserAdmin = false
}) => {
    try {
        if (!from.endsWith('@g.us')) return { ok: true }

        const metadata = await sock.groupMetadata(from)
        const botJid = sock.user?.id || sock.user?.jid
        const botParticipant = metadata.participants.find(p => p.id === botJid)
        const userParticipant = metadata.participants.find(p => p.id === sender)

        // Verifica se o bot é admin
        if (requireBotAdmin && (!botParticipant || botParticipant.admin !== 'admin')) {
            await responder({
                sock,
                from,
                msg,
                texto: '❌ Ops! Eu não sou admin neste grupo, não posso executar este comando.',
                titulo: 'Sistema Auxiliar ⚡',
                subtitulo: 'Bot precisa ser admin',
                imagem: 'https://i.imgur.com/vdmgNvS.jpeg'
            })
            return { ok: false, error: true }
        }

        // Verifica se o usuário é admin
        if (requireUserAdmin && (!userParticipant || (userParticipant.admin !== 'admin' && userParticipant.admin !== 'superadmin'))) {
            await responder({
                sock,
                from,
                msg,
                texto: '❌ Você precisa ser admin para usar este comando!',
                titulo: 'Sistema Auxiliar ⚡',
                subtitulo: 'Permissão negada',
                imagem: 'https://i.imgur.com/vdmgNvS.jpeg'
            })
            return { ok: false, error: true }
        }

        return { ok: true }
    } catch (err) {
        console.log('Erro no adminCheck:', err)
        await responder({
            sock,
            from,
            msg,
            texto: '⚠️ Ocorreu um erro ao verificar permissões.',
            titulo: 'Sistema Auxiliar ⚡',
            subtitulo: 'Erro interno',
            imagem: 'https://i.imgur.com/vdmgNvS.jpeg'
        })
        return { ok: false, error: true }
    }
}
