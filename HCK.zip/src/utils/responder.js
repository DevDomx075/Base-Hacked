const bordas = require('./bordas')

module.exports = async ({
    sock,
    from,
    msg,
    texto = '',
    titulo = '',
    subtitulo = '',
    imagem = 'https://i.imgur.com/vdmgNvS.jpeg', // <-- sua foto fixa
    link = '',
    canalJid = '',
    canalNome = ''
}) => {
    try {
        let conteudo = bordas.cmd(
            titulo || 'ˢʸˢᵗᵉᵐHACKΞD',
            `${texto}

───────────────
💀 ${titulo}
⚡ ${subtitulo}`
        )

        const contextInfo = {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: canalJid || '120363424816359070@newsletter',
                newsletterName: canalNome || '✦ ˢʸˢᵗᵉᵐHACKΞD ✦',
                serverMessageId: 1
            }
        }

        // ✅ ENVIA A IMAGEM FIXA
        return await sock.sendMessage(from, {
            image: { url: imagem },
            caption: conteudo,
            contextInfo,
		mentions: [msg.key.participant || msg.key.remoteJid]
        }, { quoted: msg })

    } catch (err) {
        console.log('Erro no responder:', err)
        return await sock.sendMessage(from, {
            text: texto || 'Erro ao responder.'
        }, { quoted: msg })
    }
}
