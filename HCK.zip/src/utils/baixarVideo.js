const { spawn } = require('child_process')
const fs = require('fs')
const path = require('path')
const responder = require('./responder')

const delay = ms => new Promise(res => setTimeout(res, ms))

async function digitando(sock, from, tempo = 2000) {
    try {
        await sock.sendPresenceUpdate('composing', from)
        await delay(tempo)
        await sock.sendPresenceUpdate('paused', from)
    } catch {}
}

function getText(msg) {
    return (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        ''
    ).trim()
}

const PYTHON = 'python3'
const YTDLP = ['-m', 'yt_dlp']

module.exports = async ({ sock, msg, from }) => {
    try {
        const text = getText(msg)
        if (!text) return

        const args = text.split(' ')
        args.shift()

        if (!args[0]) {
            return responder({
                sock,
                from,
                msg,
                texto: '❌ Envie um link válido.'
            })
        }

        const url = args[0]

        if (msg.key) {
            await sock.sendMessage(from, {
                react: { text: '⬇️', key: msg.key }
            })
        }

        await digitando(sock, from, 2000)

        const dir = '/data/data/com.termux/files/home/HCK/src/tmp'
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

        const raw = path.join(dir, `raw_${Date.now()}.mp4`)
        const final = path.join(dir, `final_${Date.now()}.mp4`)

        // 📥 download
        const dl = spawn(PYTHON, [
            ...YTDLP,
            '-f', 'bestvideo+bestaudio',
            '--merge-output-format', 'mp4',
            '-o', raw,
            url
        ])

        dl.on('close', async () => {

            if (!fs.existsSync(raw)) {
                return responder({ sock, from, msg, texto: '❌ Erro ao baixar.' })
            }

            // 🔄 converter
            const ffmpeg = spawn('ffmpeg', [
                '-i', raw,
                '-vf', 'scale=1280:-2',
                '-c:v', 'libx264',
                '-preset', 'fast',
                '-crf', '28',
                '-c:a', 'aac',
                '-b:a', '128k',
                '-movflags', '+faststart',
                final
            ])

            ffmpeg.on('close', async () => {

                if (!fs.existsSync(final)) {
                    return responder({ sock, from, msg, texto: '❌ Erro ao converter.' })
                }

                await responder({
                    sock,
                    from,
                    msg,
                    texto: '🎬 Enviando vídeo...'
                })

                await sock.sendMessage(from, {
                    video: { url: final },
                    mimetype: 'video/mp4',
                    caption: '🎬 Download concluído'
                }, { quoted: msg })

                fs.unlinkSync(raw)
                fs.unlinkSync(final)

                if (msg.key) {
                    await sock.sendMessage(from, {
                        react: { text: '✅', key: msg.key }
                    })
                }
            })
        })

    } catch (err) {
        console.log('Erro downloader:', err)
    }
}
