const fs = require('fs')
const path = require('path')
const config = require('../config')
const bordas = require('./utils/bordas')
const responder = require('./utils/responder')

// ⏳ delay
const delay = ms => new Promise(res => setTimeout(res, ms))

// ✍🏿 digitando
async function digitando(sock, jid) {
    try {
        await sock.sendPresenceUpdate('composing', jid)
        await delay(400 + Math.random() * 400)
        await sock.sendPresenceUpdate('paused', jid)
    } catch {}
}

// 🎤 gravando áudio
async function gravando(sock, jid) {
    try {
        await sock.sendPresenceUpdate('recording', jid)
        await delay(1200)
        await sock.sendPresenceUpdate('paused', jid)
    } catch {}
}

module.exports = async (sock, msg) => {
    try {
        // ==============================
        // 🔐 SEGURANÇA
        // ==============================
        if (!msg) return

        // 👥 EVENTOS DE GRUPO (boas-vindas / saída)
        if (msg.type === 'group-update') {
            const { id, participants, action } = msg.data

            const dbPath = path.join(__dirname, './database/welcome.json')
            if (!fs.existsSync(dbPath)) return

            const db = JSON.parse(fs.readFileSync(dbPath))
            if (!db[id]) return

            for (const user of participants) {
                if (action === 'add') {
                    await sock.sendMessage(id, {
                        text: bordas.sucesso('👋 Bem-vindo', `@${user.split('@')[0]}\nEntrou no grupo 🔥`),
                        mentions: [user]
                    })
                }

                if (action === 'remove') {
                    await sock.sendMessage(id, {
                        text: bordas.alerta('👋 Saiu', `@${user.split('@')[0]}\nSaiu do grupo...`),
                        mentions: [user]
                    })
                }
            }
            return
        }

        if (!msg.message) return

        const messageContent = msg.message
        const from = msg.key.remoteJid
        const isGroup = from.endsWith('@g.us')
        const sender = msg.key.participant || from
        const senderNumber = sender.split('@')[0]

        const isOwner =
            config.donos.includes(sender) ||
            config.donos.includes(senderNumber)

        const text =
            messageContent.conversation ||
            messageContent.extendedTextMessage?.text ||
            ''

        if (!text) return

        // ==============================
        // 🚫 ANTILINK
        // ==============================
        if (isGroup) {
            const dbPath = path.join(__dirname, './database/antilink.json')
            if (fs.existsSync(dbPath)) {
                const db = JSON.parse(fs.readFileSync(dbPath))

                if (db[from]) {
                    const isLink = /(https?:\/\/|www\.|chat\.whatsapp\.com)/gi.test(text)

                    if (isLink) {
                        const metadata = await sock.groupMetadata(from)
                        const userData = metadata.participants.find(p => p.id === sender)

                        const isAdmin =
                            userData?.admin === 'admin' ||
                            userData?.admin === 'superadmin'

                        if (!isAdmin && !isOwner) {
                            await sock.sendMessage(from, { delete: msg.key })

                            await sock.sendMessage(from, {
                                text: bordas.erro('🚫 ANTILINK', `@${senderNumber}\nLinks não são permitidos 🚫`),
                                mentions: [sender]
                            })
                            return
                        }
                    }
                }
            }
        }

        // ==============================
        // 🛡️ ANTI-GRUPO
        // ==============================
        if (isGroup) {
            const dbPathGrupo = path.join(__dirname, './database/antigrupo.json')
            if (fs.existsSync(dbPathGrupo)) {
                const dbGrupo = JSON.parse(fs.readFileSync(dbPathGrupo))

                if (dbGrupo[from]) {
                    const groupMentions =
                        msg.message?.extendedTextMessage?.contextInfo?.groupMentions

                    if (groupMentions?.length > 0) {
                        const metadata = await sock.groupMetadata(from)
                        const userData = metadata.participants.find(p => p.id === sender)

                        const isAdmin =
                            userData?.admin === 'admin' ||
                            userData?.admin === 'superadmin'

                        if (!isAdmin && !isOwner) {
                            await sock.sendMessage(from, { delete: msg.key })

                            await sock.sendMessage(from, {
                                text: bordas.erro('🛡️ ANTI-GRUPO', `@${senderNumber}\nMenções não permitidas 🚫`),
                                mentions: [sender]
                            })
                            return
                        }
                    }
                }
            }
        }

        // ==============================
        // ⚙️ COMANDOS
        // ==============================
        if (!text.startsWith(config.prefixo)) return

        const args = text.slice(config.prefixo.length).trim().split(/ +/)
        const cmdName = args.shift().toLowerCase()

        // ⚡ comandos rápidos
        const comandosRapidos = [
            'ban','colapso','despromover','adv','wipe',
            'abrir','antilink','promover','fechar',
            'nukeadm','kickall','rmadv'
        ]

        // 🎤 comandos de áudio
        const comandosAudio = ['play','musica','song']

        // ==============================
        // 🔎 CARREGAR COMANDOS
        // ==============================
        const commandsPath = path.join(__dirname, 'commands')
        const categories = fs.readdirSync(commandsPath)

        let command = null
        let allCommands = []

        for (const category of categories) {
            const categoryPath = path.join(commandsPath, category)
            if (!fs.lstatSync(categoryPath).isDirectory()) continue

            const files = fs.readdirSync(categoryPath)

            for (const file of files) {
                if (!file.endsWith('.js')) continue

                const cmd = require(path.join(categoryPath, file))

                if (cmd.name) allCommands.push(cmd.name)
                if (cmd.aliases) allCommands.push(...cmd.aliases)

                if (cmd.name === cmdName || cmd.aliases?.includes(cmdName)) {
                    command = cmd
                }
            }
        }

        // ==============================
        // 🚫 COMANDO NÃO ENCONTRADO
        // ==============================
        if (!command) {
            await digitando(sock, from)

            let sugestao = null
            let perc = 0

            for (const c of allCommands) {
                let match = 0
                for (let i = 0; i < Math.min(c.length, cmdName.length); i++) {
                    if (c[i] === cmdName[i]) match++
                    else break
                }

                let percentual = Math.floor((match / c.length) * 100)

                if (percentual > perc) {
                    perc = percentual
                    sugestao = c
                }
            }

            let texto = bordas.erro('❌ Comando não encontrado',
`Comando: *${cmdName}*

💔 O comando não existe!`)

            if (sugestao && perc >= 30) {
                texto += `\n💡 Talvez quis dizer: *!${sugestao}*\n🔎 Similaridade: ${perc}%`
            } else {
                texto += `\n📌 Digite *!menu* para ver comandos.`
            }

            await responder({
                sock,
                from,
                msg,
                texto,
                titulo: config.nomeBot,
                subtitulo: 'Erro de comando',
                imagem: 'https://i.imgur.com/2mqr1Nh.jpeg',
                link: 'https://i.imgur.com/vdmgNvS.jpeg',
                canalJid: '120363424816359070@newsletter',
                canalNome: '✦ Canal Oficial ✦'
            })
            return
        }

        // ==============================
        // 👾 REAÇÃO
        // ==============================
        try {
            await sock.sendMessage(from, {
                react: { text: '👾', key: msg.key }
            })
        } catch {}

        // ==============================
        // ✍🏿 SIMULAÇÃO GLOBAL
        // ==============================
        if (comandosAudio.includes(cmdName)) {
            await gravando(sock, from)
        } else {
            await digitando(sock, from)
        }

        // ==============================
        // 🔥 INTERCEPTOR
        // ==============================
        const sockMod = { ...sock }

        sockMod.sendMessage = async (jid, content, options = {}) => {
            try {
                if (comandosRapidos.includes(cmdName)) {
                    return await sock.sendMessage(jid, content, options)
                }

                if (content?.text) {
                    return await responder({
                        sock,
                        from: jid,
                        msg,
                        sender,
                        texto: content.text,

                        titulo: config.nomeBot,
                        subtitulo: 'Sistema ativo ⚡',

                        link: 'https://whatsapp.com/channel/0029Vb8JT97Bqbr0l2xvIP31',
                        canalJid: '120363424816359070@newsletter',
                        canalNome: '✦ Canal Oficial ✦'
                    })
                }

                return await sock.sendMessage(jid, content, options)

            } catch (err) {
                console.log('Erro interceptor:', err)
                return await sock.sendMessage(jid, content, options)
            }
        }

        // ==============================
        // 🚀 EXECUTAR COMANDO
        // ==============================
        await command.run({
            sock: sockMod,
            msg,
            args,
            from,
            sender,
            isOwner,
            config
        })

    } catch (err) {
        console.error('Erro no handler:', err)
    }
}
